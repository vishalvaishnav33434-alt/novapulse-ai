require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const OpenAI = require("openai");

const app = express();
const PORT = process.env.PORT || 3000;
const uploadDir = path.join(__dirname, "uploads");
fs.mkdirSync(uploadDir, { recursive: true });

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));
app.use("/api/", rateLimit({ windowMs: 60 * 1000, limit: 40, standardHeaders: true, legacyHeaders: false }));

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => {
    const safe = file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_").slice(-90);
    cb(null, `${Date.now()}-${safe}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => {
    const allowed = /^(image\/(png|jpeg|webp|gif)|application\/pdf|text\/plain)$/i.test(file.mimetype);
    cb(allowed ? null : new Error("Only PNG/JPG/WEBP/GIF, PDF, or TXT files are allowed."), allowed);
  }
});

function getClient() {
  if (!process.env.OPENAI_API_KEY) return null;
  return new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
}
function requireAdmin(req, res, next) {
  const supplied = req.get("x-admin-password") || "";
  const expected = process.env.ADMIN_PASSWORD || "";
  if (!expected || expected === "change-this-before-deploying") {
    return res.status(503).json({ error: "Set a unique ADMIN_PASSWORD in environment variables first." });
  }
  if (supplied !== expected) return res.status(401).json({ error: "Incorrect admin password." });
  next();
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, mode: process.env.OPENAI_API_KEY ? "live" : "demo", app: "NovaPulse AI" });
});

app.post("/api/chat", async (req, res) => {
  const message = String(req.body?.message || "").trim().slice(0, 12000);
  const history = Array.isArray(req.body?.history) ? req.body.history.slice(-12) : [];
  if (!message) return res.status(400).json({ error: "Please enter a message." });

  const client = getClient();
  if (!client) {
    return res.json({
      mode: "demo",
      reply: `You're using NovaPulse demo mode, so this reply is generated locally—not by a live AI model.\\n\\nYou asked: “${message.slice(0, 500)}”\\n\\nTo enable real AI, add OPENAI_API_KEY in Railway → Service → Variables, then redeploy. You can also explore the Writing, Coding, Image Studio, and Documents tools in this interface.`
    });
  }

  try {
    const safeHistory = history
      .filter(m => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
      .map(m => ({ role: m.role, content: m.content.slice(0, 6000) }));
    const completion = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      messages: [
        { role: "system", content: "You are NovaPulse, a helpful AI assistant. Be accurate, clear, and concise. If uncertain, say so." },
        ...safeHistory,
        { role: "user", content: message }
      ],
      temperature: 0.7
    });
    res.json({ mode: "live", reply: completion.choices?.[0]?.message?.content || "I couldn't create a reply. Please try again." });
  } catch (err) {
    console.error("Chat provider error:", err.message);
    res.status(502).json({ error: "AI provider request failed. Check your API key, model access, and provider billing." });
  }
});

app.post("/api/image", async (req, res) => {
  const prompt = String(req.body?.prompt || "").trim().slice(0, 3000);
  if (!prompt) return res.status(400).json({ error: "Describe the image you want." });
  const client = getClient();
  if (!client) return res.status(503).json({ error: "Image generation needs OPENAI_API_KEY and image-model access. Demo mode does not generate real images." });
  try {
    const result = await client.images.generate({
      model: process.env.OPENAI_IMAGE_MODEL || "gpt-image-1",
      prompt,
      size: "1024x1024"
    });
    const b64 = result.data?.[0]?.b64_json;
    if (!b64) throw new Error("Provider returned no image data");
    res.json({ image: `data:image/png;base64,${b64}`, mode: "live" });
  } catch (err) {
    console.error("Image provider error:", err.message);
    res.status(502).json({ error: "Image generation failed. Check image model access, API key, and provider billing." });
  }
});

app.post("/api/upload", (req, res) => {
  upload.single("file")(req, res, err => {
    if (err) return res.status(400).json({ error: err.message || "Upload failed." });
    if (!req.file) return res.status(400).json({ error: "Choose a file first." });
    res.json({ ok: true, filename: req.file.filename, originalName: req.file.originalname, size: req.file.size, note: "Stored on this server's local filesystem. Configure persistent storage before relying on it in production." });
  });
});

app.get("/api/admin/stats", requireAdmin, (_req, res) => {
  let files = [];
  try { files = fs.readdirSync(uploadDir).filter(name => name !== ".gitkeep"); } catch {}
  res.json({
    app: "NovaPulse AI",
    aiMode: process.env.OPENAI_API_KEY ? "Live API configured" : "Demo mode",
    uploadedFiles: files.length,
    node: process.version,
    uptimeSeconds: Math.round(process.uptime())
  });
});

app.get("/admin", (_req, res) => res.sendFile(path.join(__dirname, "public", "admin.html")));
app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, "0.0.0.0", () => console.log(`NovaPulse AI listening on ${PORT}`));
