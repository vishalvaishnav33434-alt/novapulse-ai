const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const state = { messages: [], conversations: [], tool: "chat", busy: false };
const panels = { image: $("#imagePanel"), writing: $("#writingPanel"), coding: $("#codingPanel"), documents: $("#documentsPanel") };

function toast(text) {
  const el = $("#toast"); el.textContent = text; el.classList.add("show");
  clearTimeout(window.__toastTimer); window.__toastTimer = setTimeout(() => el.classList.remove("show"), 3200);
}
function showTool(tool) {
  state.tool = tool;
  $("#welcome").classList.toggle("hidden", tool !== "chat" || state.messages.length > 0);
  $("#conversation").classList.toggle("hidden", tool !== "chat" || state.messages.length === 0);
  Object.entries(panels).forEach(([name, el]) => el.classList.toggle("hidden", name !== tool));
  $("#composerWrap").classList.toggle("hidden", tool !== "chat");
  const labels = { chat: "AI Assistant", image: "Image Studio", writing: "AI Writer", coding: "Code Copilot", documents: "Documents" };
  $("#pageCrumb").textContent = labels[tool] || labels.chat;
  $$(".nav-item").forEach(el => el.classList.toggle("active", el.dataset.tool === tool));
  $("#sidebar").classList.remove("open");
}
function renderMessages() {
  const root = $("#messages"); root.innerHTML = "";
  state.messages.forEach(m => {
    const el = document.createElement("div"); el.className = `message ${m.role}`;
    const avatar = document.createElement("div"); avatar.className = "message-avatar"; avatar.textContent = m.role === "user" ? "Y" : "✳";
    const body = document.createElement("div"); body.className = "message-body";
    const label = document.createElement("div"); label.className = "message-label"; label.textContent = m.role === "user" ? "YOU" : "NOVAPULSE";
    const content = document.createElement("div"); content.className = "message-content"; content.textContent = m.content;
    body.append(label, content); el.append(avatar, body); root.append(el);
  });
  $("#welcome").classList.toggle("hidden", state.messages.length > 0);
  $("#conversation").classList.toggle("hidden", state.messages.length === 0);
  root.lastElementChild?.scrollIntoView({ behavior: "smooth", block: "nearest" });
}
function saveConversation() {
  try {
    let saved = JSON.parse(localStorage.getItem("novapulse-conversations") || "[]");
    if (state.messages.length) {
      const title = state.messages.find(m => m.role === "user")?.content.slice(0, 42) || "New conversation";
      saved.unshift({ title, messages: state.messages, updated: Date.now() });
      saved = saved.slice(0, 12); localStorage.setItem("novapulse-conversations", JSON.stringify(saved));
    }
  } catch {}
  renderHistory();
}
function renderHistory() {
  const root = $("#historyList"); root.innerHTML = "";
  let saved = []; try { saved = JSON.parse(localStorage.getItem("novapulse-conversations") || "[]"); } catch {}
  if (!saved.length) { root.innerHTML = '<div class="history-empty">Your conversations will appear here.</div>'; return; }
  saved.slice(0, 8).forEach(item => {
    const btn = document.createElement("button"); btn.className = "history-entry"; btn.textContent = item.title;
    btn.onclick = () => { state.messages = item.messages || []; renderMessages(); showTool("chat"); }; root.append(btn);
  });
}
async function sendMessage(text) {
  const message = (text ?? $("#messageInput").value).trim();
  if (!message || state.busy) return;
  if (state.tool !== "chat") showTool("chat");
  state.busy = true; $("#messageInput").value = ""; $("#sendButton").textContent = "…";
  const history = state.messages.slice(-12);
  state.messages.push({ role: "user", content: message });
  state.messages.push({ role: "assistant", content: "Thinking…" });
  renderMessages();
  try {
    const response = await fetch("/api/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message, history }) });
    const data = await response.json();
    state.messages[state.messages.length - 1].content = response.ok ? data.reply : (data.error || "Something went wrong.");
    if (data.mode === "live") { $("#modeText").textContent = "LIVE AI"; $(".status").classList.add("live"); }
    else if (data.mode === "demo") toast("Demo mode: add an API key for real AI responses.");
  } catch { state.messages[state.messages.length - 1].content = "Could not reach the server. Check your connection and try again."; }
  finally { state.busy = false; $("#sendButton").textContent = "↑"; renderMessages(); saveConversation(); }
}
$("#sendButton").addEventListener("click", () => sendMessage());
$("#messageInput").addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } });
$("#messageInput").addEventListener("input", e => { e.target.style.height = "auto"; e.target.style.height = Math.min(e.target.scrollHeight, 180) + "px"; });
$("#newChat").onclick = () => { if (state.messages.length) saveConversation(); state.messages = []; renderMessages(); showTool("chat"); $("#messageInput").focus(); };
$$(".nav-item").forEach(el => el.onclick = () => showTool(el.dataset.tool));
$$(".suggestion[data-prompt]").forEach(el => el.onclick = () => sendMessage(el.dataset.prompt));
$$(".suggestion[data-open]").forEach(el => el.onclick = () => showTool(el.dataset.open));
$$("[data-write]").forEach(el => el.onclick = () => sendMessage(el.dataset.write));
$$("[data-code]").forEach(el => el.onclick = () => sendMessage(el.dataset.code));
$("#attachButton").onclick = () => showTool("documents");
$("#mobileMenu").onclick = () => $("#sidebar").classList.toggle("open");
$("#themeButton").onclick = () => document.body.classList.toggle("soft-glow");
$("#explorePlans").onclick = () => toast("This starter is free to test. Add subscription billing when you are ready.");
$("#generateImage").onclick = async () => {
  const prompt = $("#imagePrompt").value.trim(); if (!prompt) return toast("Describe the image first.");
  const button = $("#generateImage"); button.disabled = true; button.textContent = "Generating…";
  $("#imageResult").textContent = "Creating your image. This may take a little while.";
  try {
    const r = await fetch("/api/image", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ prompt }) });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || "Image generation failed.");
    const img = document.createElement("img"); img.src = d.image; img.alt = prompt;
    $("#imageResult").innerHTML = ""; $("#imageResult").append(img);
  } catch (e) { $("#imageResult").textContent = e.message; }
  finally { button.disabled = false; button.innerHTML = '✦ Generate image <span>↗</span>'; }
};
$("#fileInput").addEventListener("change", async e => {
  const file = e.target.files[0]; if (!file) return;
  const fd = new FormData(); fd.append("file", file); $("#uploadResult").textContent = "Uploading…";
  try {
    const r = await fetch("/api/upload", { method: "POST", body: fd }); const d = await r.json();
    $("#uploadResult").textContent = r.ok ? `✓ Uploaded ${d.originalName} (${Math.ceil(d.size / 1024)} KB). ${d.note}` : `Upload failed: ${d.error}`;
  } catch { $("#uploadResult").textContent = "Upload failed. Check the server connection."; }
  e.target.value = "";
});
fetch("/api/health").then(r => r.json()).then(d => {
  if (d.mode === "live") { $("#modeText").textContent = "LIVE AI"; $(".status").classList.add("live"); }
}).catch(() => {});
renderHistory(); showTool("chat");
